# Сторонние компоненты

- **Code — OSS**: Copyright Microsoft Corporation and contributors. Лицензия upstream: [`flexual-src/Code-OSS-LICENSE.txt`](../flexual-src/Code-OSS-LICENSE.txt). Уведомления upstream: [`Code-OSS-ThirdPartyNotices.txt`](Code-OSS-ThirdPartyNotices.txt).
- **VSCodium**: [`1.143.17232`](https://github.com/VSCodium/vscodium/releases/tag/1.143.17232), источник пакетов для сборки. [Лицензия проекта VSCodium](https://github.com/VSCodium/vscodium/blob/master/LICENSE).
- **fflate 0.8.2**: [проект](https://github.com/101arrowz/fflate); лицензия [`flexual-src/vendor/fflate-LICENSE.txt`](../flexual-src/vendor/fflate-LICENSE.txt).
- **Electron/Chromium**, системные расширения и прочие компоненты исходного дистрибутива: соответствующие лицензии и уведомления поставляются в оригинальном дистрибутиве и в установочных пакетах, где эти компоненты используются.

Лицензии сторонних компонентов не задают автоматически условия для отдельно добавленного оформления и кода Flexual. Если вы хотите оформить весь репозиторий как open source, отдельно определите лицензию для своих материалов.
