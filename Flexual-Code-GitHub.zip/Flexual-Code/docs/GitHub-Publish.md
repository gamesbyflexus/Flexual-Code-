# Как опубликовать Flexual Code на GitHub

## 1. Загрузите исходники в репозиторий

1. Распакуйте `Flexual-Code-GitHub.zip`. Внутри будет папка `Flexual-Code`.
2. Откройте [github.com/new](https://github.com/new), создайте репозиторий, например `flexual-code`. Выберите **Public**, если исходники и установщики должны быть доступны всем. Для публикации через Git оставьте новый репозиторий пустым, не создавая README на GitHub.
3. Загрузите **содержимое** распакованной папки в корень репозитория, включая `.github`, `.gitignore` и `.gitattributes`. Через браузер: **uploading an existing file** в пустом репозитории или **Add file → Upload files**. Не загружайте сам ZIP вместо исходников. Если браузер пропускает скрытые файлы или папки, воспользуйтесь Git:

   ```sh
   git init -b main
   git add .
   git commit -m "Publish Flexual Code source"
   git remote add origin https://github.com/ВАШ_ЛОГИН/ВАШ_РЕПОЗИТОРИЙ.git
   git push -u origin main
   ```

   Запускайте команды **из распакованной папки `Flexual-Code`**. Установщики и приватный ключ в архив не входят; коммитить их не нужно.

## 2. Опубликуйте установщики в Releases

1. В репозитории откройте **Releases → Draft a new release**.
2. В **Choose a tag** создайте `v1.2.0`, укажите ветку `main`. Заголовок: **Flexual Code — Android 1.2.0 / Windows 1.1.0**. Текст описания есть в `docs/RELEASE-v1.2.0.md`.
3. Прикрепите скачанные файлы, сохранив их имена:

   | Файл | Что это |
   |---|---|
   | `Flexual-Code-Setup-x64.exe` | Полный установщик Windows (~151 МиБ) |
   | `Flexual-Code-Web-Setup-x64.exe` | Веб-установщик Windows (~4,3 МиБ) |
   | `Flexual-Code-Android.apk` | Установщик Android (~20 МиБ) |
   | `SHA256SUMS.txt` | Контрольные суммы тех же трёх файлов |

4. Нажмите **Publish release**. Откройте опубликованный релиз без авторизации (например, в приватном окне) и проверьте кнопки загрузки.

**Не добавляйте EXE в Git.** Полный установщик превышает [лимит GitHub для файлов в репозитории](https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github). Файлы, добавленные к [GitHub Release](https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository), хранятся отдельно. Для обновления уже установленного APK нужен тот же приватный ключ. Не загружайте ключ и его пароль ни в репозиторий, ни в Releases.

## 3. Включите страницу загрузок (необязательно)

1. В репозитории откройте **Settings → Pages → Build and deployment → Source → GitHub Actions**.
2. Откройте **Actions → Publish download page → Run workflow**, выберите `main`. Если первый запуск завершился до включения Pages, запустите его повторно после включения.
3. Готовый адрес появится в **Settings → Pages**. Страница подставляет адрес вашего репозитория автоматически. Она загружает пакеты из релиза с тегом, указанным в `release.json`, а не из репозитория.

Если сайт не нужен, достаточно шагов 1–2: ссылки на EXE и APK уже будут в Releases. При следующем релизе измените тег в `release.json` и прикрепите все перечисленные там файлы под теми же именами.
