#!/usr/bin/env python3
"""Serve only the Flexual download page and its public assets."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
import mimetypes
import re

ROOT = Path(__file__).resolve().parent
DOWNLOADS = {
    'Flexual-Code-Setup-x64.exe': 'application/octet-stream',
    'Flexual-Code-Web-Setup-x64.exe': 'application/octet-stream',
    'Flexual-Code-Android.apk': 'application/vnd.android.package-archive',
    'SHA256SUMS.txt': 'text/plain; charset=utf-8',
}
PUBLIC = {'/': 'index.html', '/index.html': 'index.html', '/assets/site.css': 'assets/site.css', '/assets/flexual.svg': 'assets/flexual.svg', '/favicon.ico': 'assets/flexual.ico'}

class Handler(BaseHTTPRequestHandler):
    def do_HEAD(self): self.serve(False)
    def do_GET(self): self.serve(True)
    def serve(self, body):
        url = urlsplit(self.path).path
        attachment = None
        if url in PUBLIC:
            p = ROOT / PUBLIC[url]
            kind = mimetypes.guess_type(p)[0] or 'application/octet-stream'
            if p.suffix in ('.css', '.html'): kind += '; charset=utf-8'
        elif url.startswith('/downloads/') and (name := url.removeprefix('/downloads/')) in DOWNLOADS:
            p = ROOT / 'downloads' / name
            kind = DOWNLOADS[name]
            if name != 'SHA256SUMS.txt': attachment = name
            # Only serve release artifacts after both files have been verified.
            if not (ROOT / 'downloads/SHA256SUMS.txt').is_file():
                self.send_error(503, 'Release is being verified'); return
        else:
            self.send_error(404); return
        try:
            f = p.open('rb')
        except OSError:
            self.send_error(404); return
        with f:
            size = p.stat().st_size
            start, end, status = 0, size - 1, 200
            if value := self.headers.get('Range'):
                match = re.fullmatch(r'bytes=(\d{0,20})-(\d{0,20})', value)
                if match:
                    a, b = match.groups()
                    if a: start, end = int(a), min(end, int(b)) if b else end
                    elif b: start = max(0, size - int(b))
                    else: start = size
                    if start >= size or end < start:
                        self.send_response(416); self.send_header('Content-Range', f'bytes */{size}'); self.end_headers(); return
                    status = 206
                else:
                    self.send_response(416); self.send_header('Content-Range', f'bytes */{size}'); self.end_headers(); return
            self.send_response(status)
            self.send_header('Content-Type',kind)
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Accept-Ranges','bytes')
            self.send_header('Content-Length',str(end-start+1))
            self.send_header('Cache-Control','no-cache')
            if attachment: self.send_header('Content-Disposition',f'attachment; filename="{attachment}"')
            if status == 206: self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
            self.end_headers()
            if body:
                try:
                    f.seek(start)
                    remain = end-start+1
                    while remain:
                        chunk = f.read(min(remain,256*1024))
                        if not chunk: break
                        self.wfile.write(chunk)
                        remain -= len(chunk)
                except (BrokenPipeError, ConnectionResetError): pass

if __name__ == '__main__':
    ThreadingHTTPServer(('0.0.0.0', 8080), Handler).serve_forever()
