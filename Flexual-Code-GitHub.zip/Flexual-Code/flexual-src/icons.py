from pathlib import Path
import io
import cairosvg
from PIL import Image
root=Path(__file__).resolve().parents[1]
p=root/'assets'
source=p/'flexual.svg'
raw=cairosvg.svg2png(url=str(source),output_width=512,output_height=512)
(p/'flexual.png').write_bytes(raw)
im=Image.open(io.BytesIO(raw)).convert('RGBA')
im.save(p/'flexual.ico', sizes=[(16,16),(24,24),(32,32),(48,48),(64,64),(128,128),(256,256)])
