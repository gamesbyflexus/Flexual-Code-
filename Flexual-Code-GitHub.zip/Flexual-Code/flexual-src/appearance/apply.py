"""Shared studio settings and renderer styling."""
from pathlib import Path
from runpy import run_path
import json,base64,hashlib,sys
here=Path(__file__).resolve().parent
build_theme=run_path(here/'build-theme.py')['build_theme']
common={
 'workbench.colorTheme':'Flexual Night','workbench.preferredDarkColorTheme':'Flexual Night','workbench.preferredLightColorTheme':'Flexual Day','workbench.iconTheme':'flexual-symbols',
 'window.autoDetectColorScheme':False,'window.title':'${activeEditorShort}${separator}Flexual Code','window.commandCenter':True,
 'workbench.startupEditor':'none','workbench.activityBar.location':'top','workbench.sideBar.location':'right','workbench.secondarySideBar.defaultVisibility':'hidden','workbench.layoutControl.enabled':False,'workbench.tips.enabled':False,
 'editor.minimap.enabled':False,'editor.fontSize':14,'editor.lineHeight':23,'editor.cursorStyle':'line','editor.cursorWidth':2,'editor.padding.top':12,'editor.padding.bottom':12,
 'editor.renderLineHighlight':'gutter','workbench.editor.tabSizing':'shrink','workbench.tree.indent':16,'workbench.tree.renderIndentGuides':'always',
}

def init(base: Path,web: bool):
    appearance=build_theme(base/'extensions')
    out=base/'out'; media=out/'media'; (media/'flexual-studio.svg').write_bytes((here/'watermark.svg').read_bytes())
    folder=out/('vs/code/browser/workbench' if web else 'vs/workbench')
    css=folder/('workbench.css' if web else 'workbench.desktop.main.css')
    prefix='../../../../media' if web else '../../media'
    detail=(here/'workbench.css').read_text().replace('__FLEXUAL_MEDIA__',prefix)
    original=css.read_text().split('/* Flexual Studio chrome.',1)[0].rstrip()
    css.write_text(original+'\n'+detail)
    return appearance

def desktop(base: Path):
    init(base,False)
    a=base/'out/vs/workbench/workbench.desktop.main.js'; s=a.read_text()
    marker='a5e.registerConfiguration(ygi);'
    patch='a5e.registerDefaultConfigurations([{overrides:'+json.dumps(common,separators=(',',':'))+'}]);/* Flexual Studio defaults */'
    if patch not in s:
        if s.count(marker)!=1: raise ValueError('Unexpected upstream renderer')
        s=s.replace(marker,marker+patch)
    a.write_text(s)
    p=base/'product.json'; d=json.loads(p.read_text());
    for k in d.get('checksums',{}):
        f=base/'out'/k
        if f.is_file(): d['checksums'][k]=base64.b64encode(hashlib.sha256(f.read_bytes()).digest()).decode().rstrip('=')
    p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')

if __name__=='__main__': desktop(Path(sys.argv[1]))
