Unicode true
!include "MUI2.nsh"
!include "LogicLib.nsh"
Name "Flexual Code"
OutFile "${OUT}"
InstallDir "$LOCALAPPDATA\Programs\Flexual Code"
RequestExecutionLevel user
!ifdef BASE_SETUP
SetCompressor lzma
!else
SetCompressor /SOLID lzma
!endif
SetCompressorDictSize 24
BrandingText "Flexual Code | Code - OSS"
Icon "${ICO}"
UninstallIcon "${ICO}"
VIProductVersion "1.1.0.0"
VIAddVersionKey "ProductName" "Flexual Code"
VIAddVersionKey "FileDescription" "Flexual Code Setup"
VIAddVersionKey "CompanyName" "Flexual Code"
VIAddVersionKey "FileVersion" "1.1.0"
VIAddVersionKey "LegalCopyright" "Code - OSS contributors; see included licenses"
!define MUI_ABORTWARNING
!define MUI_ICON "${ICO}"
!define MUI_UNICON "${ICO}"
!define MUI_FINISHPAGE_RUN "$INSTDIR\FlexualCode.exe"
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Russian"
!insertmacro MUI_LANGUAGE "English"
Function .onInit
  StrCpy $INSTDIR "$LOCALAPPDATA\Programs\Flexual Code"
FunctionEnd
Section
  SetOutPath "$INSTDIR"
!ifdef NETWORK
  InitPluginsDir
  SetOutPath "$PLUGINSDIR"
  File /r "${PAYLOAD}/*"
  DetailPrint "Downloading the verified Code - OSS package from GitHub..."
  nsExec::ExecToLog '$SYSDIR\WindowsPowerShell\v1.0\powershell.exe -NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -File "$PLUGINSDIR\install.ps1" -InstallPath "$INSTDIR"'
  Pop $0
  ${If} $0 != 0
    SetErrorLevel 1
    IfSilent +2 0
    MessageBox MB_ICONSTOP|MB_OK "Flexual Code Setup could not complete. Check your connection to GitHub and try again. Details: %TEMP%\Flexual-Code-Setup-Error.txt"
    Abort "Windows installation failed."
  ${EndIf}
!else
!ifdef BASE_SETUP
  InitPluginsDir
  SetOutPath "$PLUGINSDIR"
  SetCompress off
  File /oname=base-setup.exe "${BASE_SETUP}"
  SetCompress auto
  DetailPrint "Installing the Code - OSS engine..."
  ExecWait '"$PLUGINSDIR\base-setup.exe" /S' $0
  ${If} $0 != 0
    SetErrorLevel 1
    IfSilent +2 0
    MessageBox MB_ICONSTOP|MB_OK "Could not install the Flexual Code engine. Close Flexual Code and try again."
    Abort "Windows installation failed."
  ${EndIf}
  SetOutPath "$INSTDIR"
!endif
  File /r "${PAYLOAD}/*"
!endif
  SetOutPath "$INSTDIR"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  CreateShortcut "$SMPROGRAMS\Flexual Code.lnk" "$INSTDIR\FlexualCode.exe" "" "$INSTDIR\FlexualCode.ico"
  CreateShortcut "$DESKTOP\Flexual Code.lnk" "$INSTDIR\FlexualCode.exe" "" "$INSTDIR\FlexualCode.ico"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\FlexualCode" "DisplayName" "Flexual Code"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\FlexualCode" "DisplayVersion" "1.1.0"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\FlexualCode" "DisplayIcon" "$INSTDIR\FlexualCode.ico"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\FlexualCode" "UninstallString" '$\"$INSTDIR\Uninstall.exe$\"'
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\FlexualCode" "NoModify" 1
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\FlexualCode" "NoRepair" 1
SectionEnd
Section "Uninstall"
  Delete "$SMPROGRAMS\Flexual Code.lnk"
  Delete "$DESKTOP\Flexual Code.lnk"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\FlexualCode"
  RMDir /r "$LOCALAPPDATA\Programs\Flexual Code"
SectionEnd
