// ZIP and local snapshot operations. Included only in the Android workbench.
const fxProjectLimit=16*1024*1024, fxProjectEntries=500;
let fxProjectRevision=0;
function fxEncode(buffer){let s='';for(let i=0;i<buffer.length;i+=16384)s+=String.fromCharCode(...buffer.subarray(i,i+16384));return btoa(s);}
function fxReadTransfer(){const chunks=flexualImport;flexualImport=[];return Uint8Array.from(atob(chunks.join('')),x=>x.charCodeAt(0));}
function fxProjectPath(raw){
  if(typeof raw!=='string'||raw.length>480||/^[\\/]|[\\:\u0000-\u001f\u007f]/.test(raw))throw Error('В ZIP обнаружен недопустимый путь.');
  const names=raw.replace(/\/$/,'').split('/');
  if(names.length>32||names.some(x=>!x||x.length>150||x==='.'||x==='..'||['__proto__','prototype','constructor'].includes(x)||/[. ]$/.test(x)))throw Error('В ZIP обнаружен недопустимый путь.');
  return names.join('/');
}
function fxTopPath(name){const p=fxProjectPath(name);if(p.includes('/'))throw Error('Выберите папку проекта.');return A.joinPath(flexualRoot,p);}
function fxFileName(input){return String(input).replace(/\.zip$/i,'').replace(/[\\/:*?"<>|\u0000-\u001f\u007f]/g,'_').replace(/^[. ]+|[. ]+$/g,'').slice(0,100)||'Project';}
async function fxWorkspaceList(){return (await flexualFiles.resolve(flexualRoot)).children??[];}
function fxAssetType(name){return /\.(html?|css|m?js|jsx|json|png|jpe?g|webp|avif|gif|svg|ico|woff2?|ttf|otf|txt|xml|webmanifest|mp[34]|wav|webm|ogg|wasm)$/i.test(name);}
async function fxCollect(folder,preview,flat){
  const out=Object.create(null);let size=0,count=0;const skip=new Set(['.git','node_modules','__MACOSX']);
  async function walk(uri,base){
    const stat=await flexualFiles.resolve(uri);
    for(const file of stat.children??[]){
      const name=file.name,path=fxProjectPath(base+name);
      if(preview&&(skip.has(name)||name.startsWith('.')))continue;
      if(++count>fxProjectEntries)throw Error('В проекте больше 500 файлов и папок.');
      if(file.isDirectory){if(!preview)out[path+'/']=new Uint8Array();if(!(preview&&flat))await walk(file.resource,path+'/');continue;}
      if(!file.isFile||(preview&&!fxAssetType(name)))continue;
      const meta=await flexualFiles.stat(file.resource);if(meta.size+size>fxProjectLimit)throw Error('Проект превышает 16 МБ.');
      const data=(await flexualFiles.readFile(file.resource)).value.buffer;size+=data.length;
      if(size>fxProjectLimit)throw Error('Проект превышает 16 МБ.');out[path]=data;
    }
  }await walk(folder,'');return out;
}
async function fxOpenProject(entries,target){
  const html=entries.find(e=>!e.directory&&/(?:^|\/)index\.html?$/i.test(e.path))??entries.find(e=>!e.directory&&/\.html?$/i.test(e.path));
  if(html)await flexualCmd('vscode.open',A.joinPath(target,html.path));
  else await flexualCmd('workbench.view.explorer');
}
Object.assign(FlexualDevice,{
  projectList:()=>flexualReport(async()=>({projects:(await fxWorkspaceList()).filter(x=>x.isDirectory).slice(0,200).map(x=>x.name)})),
  finishProjectImport:rawName=>flexualReport(async()=>{
    const packed=fxReadTransfer();if(packed.length>fxProjectLimit+131072)throw Error('Архив слишком большой.');
    const entries=[], seen=new Map();let size=0;
    let files;
    try{files=fflate.unzipSync(packed,{filter:e=>{
      if(entries.length>=fxProjectEntries)throw Error('В ZIP больше 500 файлов и папок.');
      const path=fxProjectPath(e.name), directory=e.name.endsWith('/');
      if(seen.has(path))throw Error('В ZIP есть повторяющиеся пути.');
      seen.set(path,directory);entries.push({path,directory,key:e.name,bytes:e.originalSize});
      size+=e.originalSize;if(size>fxProjectLimit)throw Error('Распакованный проект превышает 16 МБ.');return !directory;
    }});}catch(e){if(e instanceof Error&&/^(В ZIP|Распакованный)/.test(e.message))throw e;throw Error('Не удалось прочитать ZIP. Проверьте, что архив не повреждён и не защищён паролем.');}
    if(!entries.length)throw Error('В архиве нет файлов или папок.');
    let total=0;for(const e of entries){
      const parts=e.path.split('/');for(let i=1;i<parts.length;i++)if(seen.get(parts.slice(0,i).join('/'))===false)throw Error('В ZIP конфликт имён файлов и папок.');
      if(!e.directory){if(!Object.hasOwn(files,e.key)||files[e.key].length!==e.bytes)throw Error('Размер записи ZIP не совпадает.');total+=files[e.key].length;}
    }
    if(total>fxProjectLimit)throw Error('Распакованный проект превышает 16 МБ.');
    const base=fxFileName(rawName);let name=base,i=2,target=fxTopPath(name);while(await flexualFiles.exists(target)){name=`${base} (${i++})`;target=fxTopPath(name);}
    await flexualFiles.createFolder(target);
    try{for(const {path,directory,key} of entries){if(!path)continue;const uri=A.joinPath(target,path);if(directory)await flexualFiles.createFolder(uri);else{const j=path.lastIndexOf('/');if(j>=0)await flexualFiles.createFolder(A.joinPath(target,path.slice(0,j)));await flexualFiles.writeFile(uri,Ve.wrap(files[key]));}}}
    catch(e){await flexualFiles.del(target,{recursive:true}).catch(()=>{});throw e;}
    await fxOpenProject(entries,target);return{name,count:entries.filter(e=>!e.directory).length};
  }),
  prepareProjectExport:name=>flexualReport(async()=>{
    await flexualCmd('workbench.action.files.saveAll');const folder=name?fxTopPath(name):flexualRoot;
    const files=await fxCollect(folder,false,false);if(!Object.keys(files).length)throw Error('В папке нет файлов для экспорта.');
    const archive=fflate.zipSync(files,{level:4});if(archive.length>fxProjectLimit+131072)throw Error('ZIP превышает 16 МБ.');
    flexualExport=fxEncode(archive);return {name:(name||'Flexual-Workspace')+'.zip',length:flexualExport.length};
  }),
  preparePreview:(savedProject,savedEntry,save)=>flexualReport(async()=>{
    if(save)await flexualCmd('workbench.action.files.saveAll');
    const active=(await mq.p).flexualEditor.activeEditor?.resource;
    let project=savedProject,entry=savedEntry;
    if(project==null){const path=active?.scheme==='flexual'?active.path.slice(flexualRoot.path.length+1):'';const parts=path.split('/');project=parts.length>1?parts.shift():'';entry=parts.join('/');}
    const folder=project?fxTopPath(project):flexualRoot;
    const files=await fxCollect(folder,true,!project);const paths=Object.keys(files);
    if(!entry||!Object.hasOwn(files,entry)||!/\.html?$/i.test(entry)){
      const dir=entry?.includes('/')?entry.slice(0,entry.lastIndexOf('/')+1):'';
      entry=[dir+'index.html',dir+'index.htm','index.html','index.htm'].find(p=>Object.hasOwn(files,p))??paths.find(p=>/(^|\/)index\.html?$/i.test(p))??paths.find(p=>/\.html?$/i.test(p));
    }
    if(!entry)throw Error('Откройте HTML-файл или проект с index.html, затем нажмите «Сайт».');
    const archive=fflate.zipSync(files,{level:1});flexualExport=fxEncode(archive);return {project,entry,length:flexualExport.length,revision:fxProjectRevision};
  }),
  previewRevision:()=>fxProjectRevision,
  insertSymbol:value=>{
    const allowed=['{','}','[',']','(',')','<','>','/','\\','=',':',';','"',"'",'`','_','+','-','*','!','&','|','→'];
    if(!allowed.includes(value))return false;
    mq.p.then(w=>{const control=w.flexualEditor.activeTextEditorControl;if(!control||typeof control.trigger!=='function'||(typeof control.hasTextFocus==='function'&&!control.hasTextFocus()))return;control.focus();if(value==='→')control.trigger('keyboard','tab',null);else control.trigger('keyboard','type',{text:value});});return true;
  }
});
