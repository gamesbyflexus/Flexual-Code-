import json, shutil, sys, hashlib, base64, uuid
from pathlib import Path
root=Path(__file__).resolve().parents[1]; win=Path(sys.argv[1]); app=win/'resources/app'
p=app/'product.json'; d=json.loads(p.read_text());
for k in ['nameShort','nameLong','win32DirName','win32NameVersion','win32RegValueName','win32ShellNameShort']:
 d[k]='Flexual Code'
d.update(applicationName='flexual',dataFolderName='.flexual-code',sharedDataFolderName='.flexual-code-shared',win32MutexName='FlexualCode.Ready',win32AppUserModelId='Flexual.FlexualCode',urlProtocol='flexual-code')
for k in ['win32AppId','win32UserAppId','win32x64AppId','win32arm64AppId','win32x64UserAppId','win32arm64UserAppId']:
 d[k]='{{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'Flexual.Code.'+k)).upper()+'}'
for k in ['updateUrl','downloadUrl','win32ContextMenu','tunnelApplicationConfig','serverDownloadUrlTemplate']:
 d.pop(k,None)
for target in [app/'out/media/code-icon.svg',app/'out/vs/workbench/browser/media/code-icon.svg']:
 if target.is_file(): shutil.copy(root/'assets/flexual.svg',target)
shutil.copy(root/'assets/flexual.ico',app/'resources/win32/code.ico')
shutil.copy(root/'assets/flexual.png',app/'resources/flexual.png')
for k in d.get('checksums',{}):
 f=app/'out'/k
 if f.is_file(): d['checksums'][k]=base64.b64encode(hashlib.sha256(f.read_bytes()).digest()).decode().rstrip('=')
p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
p=app/'package.json'; d=json.loads(p.read_text()); d['name']='Flexual Code'; p.write_text(json.dumps(d,indent=2)+'\n')
cmd=win/'bin/codium.cmd'; script=cmd.read_bytes().replace(b'VSCodium.exe',b'FlexualCode.exe'); (win/'bin/flexual.cmd').write_bytes(script); cmd.unlink()
bat=win/'bin/codium'; script=bat.read_bytes().replace(b'APP_NAME="codium"',b'APP_NAME="flexual"').replace(b'NAME="VSCodium"',b'NAME="Flexual Code"'); (win/'bin/flexual').write_bytes(script); bat.unlink()
shutil.copy(root/'assets/flexual.ico',win/'FlexualCode.ico')
