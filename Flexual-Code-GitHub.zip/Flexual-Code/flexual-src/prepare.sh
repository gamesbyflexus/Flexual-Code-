#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p .cache/flexual
cd .cache/flexual
base='https://github.com/VSCodium/vscodium/releases/download/1.143.17232'
[[ -f win.zip ]] || curl -fL --retry 2 "$base/VSCodium-win32-x64-1.143.17232.zip" -o win.zip
[[ -f web.tgz ]] || curl -fL --retry 2 "$base/vscodium-reh-web-linux-x64-1.143.17232.tar.gz" -o web.tgz
sha256sum -c <<SUMS
a1090868af8ac0ac04c22d79fdd02246fa115a78daf38a741d8db06df1753c1d  win.zip
0d1e00fa4e3564617aba798a88395d9a5fb507d771d711e0454bb1065a030f7c  web.tgz
SUMS
mkdir -p win web
[[ -f win/VSCodium.exe || -f win/FlexualCode.exe ]] || unzip -q win.zip -d win
[[ -f web/product.json ]] || tar -xzf web.tgz --strip-components=1 -C web
mkdir -p sdk
[[ -f android-platform.zip ]] || curl -fL https://dl.google.com/android/repository/platform-35_r02.zip -o android-platform.zip
[[ -f android-build.zip ]] || curl -fL https://dl.google.com/android/repository/build-tools_r35_linux.zip -o android-build.zip
[[ -f sdk/platform/android-35/android.jar ]] || unzip -q android-platform.zip -d sdk/platform
[[ -f sdk/build/android-15/apksigner ]] || unzip -q android-build.zip -d sdk/build
npm install --no-audit --no-fund resedit@3.1.1
