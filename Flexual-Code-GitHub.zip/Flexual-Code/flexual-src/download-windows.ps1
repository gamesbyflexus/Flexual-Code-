param([Parameter(Mandatory=$true)][string]$InstallPath)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$zip = Join-Path $PSScriptRoot 'upstream.zip'
$staged = Join-Path $PSScriptRoot 'payload'
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -UseBasicParsing -TimeoutSec 300 -Uri 'https://github.com/VSCodium/vscodium/releases/download/1.143.17232/VSCodium-win32-x64-1.143.17232.zip' -OutFile $zip
    if ((Get-FileHash -Algorithm SHA256 -Path $zip).Hash -ne 'a1090868af8ac0ac04c22d79fdd02246fa115a78daf38a741d8db06df1753c1d') { throw 'Download checksum mismatch.' }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::ExtractToDirectory($zip, $staged)
    $oldExe = Join-Path $staged 'VSCodium.exe'
    $stream = [IO.File]::Open($oldExe,[IO.FileMode]::Open,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try {
        $header = [IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'header.bin'))
        $stream.Write($header,0,$header.Length)
        $stream.Position = 237788672
        $resources = [IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'resources.bin'))
        $stream.Write($resources,0,$resources.Length)
    } finally { $stream.Dispose() }
    if ((Get-FileHash -Algorithm SHA256 -Path $oldExe).Hash -ne 'EXE_SHA256_PLACEHOLDER') { throw 'Editor checksum mismatch.' }
    Rename-Item -LiteralPath $oldExe -NewName 'FlexualCode.exe'
    Remove-Item -LiteralPath (Join-Path $staged 'bin\codium.cmd'),(Join-Path $staged 'bin\codium')
    Copy-Item -Path (Join-Path $PSScriptRoot 'files\*') -Destination $staged -Recurse -Force
    [void][IO.Directory]::CreateDirectory($InstallPath)
    Copy-Item -Path (Join-Path $staged '*') -Destination $InstallPath -Recurse -Force
    exit 0
} catch {
    $_ | Out-File -FilePath (Join-Path $env:TEMP 'Flexual-Code-Setup-Error.txt') -Encoding utf8
    exit 1
}
