"""Package only our changes; the Windows web installer verifies upstream before applying them."""
from pathlib import Path
from zipfile import ZipFile
import hashlib, shutil, sys
root=Path(__file__).resolve().parents[1]; cache=Path(sys.argv[1]); win=cache/'win'; stage=cache/'network-overlay'; stage.mkdir(exist_ok=True)
regions=[(0,1536,'header.bin'),(237788672,222720,'resources.bin')]
with ZipFile(cache/'win.zip') as z,z.open('VSCodium.exe') as original,(win/'FlexualCode.exe').open('rb') as mod:
    offset=0; digest=hashlib.sha256()
    while chunk:=original.read(1024*1024):
        updated=mod.read(len(chunk)); rebuilt=bytearray(chunk)
        for a,length,label in regions:
            start=max(a,offset); end=min(a+length,offset+len(chunk));
            if start<end:
                rebuilt[start-offset:end-offset]=updated[start-offset:end-offset]
                with (stage/label).open('ab' if start>a else 'wb') as f: f.write(updated[start-offset:end-offset])
        assert bytes(rebuilt)==updated, f'Unexpected executable changes near {offset}'
        digest.update(rebuilt);offset+=len(chunk)
    assert not mod.read(1)
paths=['FlexualCode.ico','bin/flexual.cmd','bin/flexual','resources/app/product.json','resources/app/package.json','resources/app/out/media/code-icon.svg','resources/app/out/vs/workbench/browser/media/code-icon.svg','resources/app/resources/win32/code.ico','resources/app/resources/flexual.png','resources/app/out/media/flexual-studio.svg','resources/app/out/vs/workbench/workbench.desktop.main.js','resources/app/out/vs/workbench/workbench.desktop.main.css']
paths += [p.relative_to(win).as_posix() for p in (win/'resources/app/extensions/theme-flexual').rglob('*') if p.is_file()]
for p in paths:
    target=stage/'files'/p
    if (win/p).is_file(): target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(win/p,target)
script=(root/'flexual-src/download-windows.ps1').read_text().replace('EXE_SHA256_PLACEHOLDER',digest.hexdigest())
(stage/'install.ps1').write_text(script,encoding='utf-8-sig')
