import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
const root=process.cwd(), cache=path.resolve(process.argv[2]);
const req=createRequire(path.join(cache,'package.json'));
const {load}=req('resedit/cjs');
const {Resource,Data,NtExecutable,NtExecutableResource}=await load();
const exe=NtExecutable.from(fs.readFileSync(path.join(cache,'win/VSCodium.exe')),{ignoreCert:true});
const res=NtExecutableResource.from(exe);
const icon=Data.IconFile.from(fs.readFileSync(path.join(root,'assets/flexual.ico')));
for(const g of Resource.IconGroupEntry.fromEntries(res.entries)) Resource.IconGroupEntry.replaceIconsForResource(res.entries,g.id,g.lang,icon.icons.map(x=>x.data));
for(const v of Resource.VersionInfo.fromEntries(res.entries)) {
  for(const lang of v.getAllLanguagesForStringValues()) v.setStringValues(lang,{FileDescription:'Flexual Code',ProductName:'Flexual Code',CompanyName:'Flexual Code',InternalName:'FlexualCode',OriginalFilename:'FlexualCode.exe'});
  v.outputToResourceEntries(res.entries);
}
res.outputResource(exe);
fs.writeFileSync(path.join(cache,'win/FlexualCode.exe'),Buffer.from(exe.generate()));
fs.unlinkSync(path.join(cache,'win/VSCodium.exe'));
