#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd); cd "$root"
cache=$(realpath "${1:-.cache/flexual}"); bt="$cache/sdk/build/android-15"; api="$cache/sdk/platform/android-35/android.jar"
export JAVA_HOME=${JAVA_HOME:-/usr/lib/jvm/java-21-openjdk-amd64}; export PATH="$JAVA_HOME/bin:$PATH"
pack="$cache/android-pack"; rm -rf "$pack"; mkdir -p "$pack/res/drawable-nodpi" "$pack/classes" "$pack/dex" "$pack/assets" downloads
cp assets/flexual.png "$pack/res/drawable-nodpi/flexual.png"; ln -s "$cache/mobile-web" "$pack/assets/ide"
"$bt/aapt2" compile --dir "$pack/res" -o "$pack/res.zip"
"$bt/aapt2" link -o "$pack/base.apk" --manifest flexual-src/android/AndroidManifest.xml -I "$api" --java "$pack" -A "$pack/assets" "$pack/res.zip"
javac --release 8 -classpath "$api" -d "$pack/classes" "$pack/app/flexual/code/R.java" flexual-src/android/*.java
mapfile -t files < <(find "$pack/classes" -name '*.class')
"$bt/d8" --min-api 28 --lib "$api" --output "$pack/dex" "${files[@]}"
(cd "$pack/dex" && zip -q "$pack/base.apk" classes.dex)
"$bt/zipalign" -f 4 "$pack/base.apk" "$pack/aligned.apk"
output=${APK_OUTPUT:-downloads/Flexual-Code-Android.apk}
alias=${FLEXUAL_KEY_ALIAS:-flexual}
key=${FLEXUAL_KEYSTORE:-"$cache/flexual-android.p12"}
pass=${FLEXUAL_KEYSTORE_PASSWORD_FILE:-"$cache/flexual-android.pass"}
if [[ -n ${FLEXUAL_KEYSTORE:-} || -n ${FLEXUAL_KEYSTORE_PASSWORD_FILE:-} ]]; then
  [[ -n ${FLEXUAL_KEYSTORE:-} && -n ${FLEXUAL_KEYSTORE_PASSWORD_FILE:-} && -f "$key" && -f "$pass" ]] || {
    echo 'Supply both an existing FLEXUAL_KEYSTORE and FLEXUAL_KEYSTORE_PASSWORD_FILE' >&2; exit 1;
  }
elif [[ ! -f "$key" ]]; then
  umask 077; openssl rand -hex 24 > "$pass"
  keytool -genkeypair -keystore "$key" -storetype PKCS12 -storepass:file "$pass" -alias "$alias" -keyalg RSA -keysize 3072 -validity 10000 -dname 'CN=Flexual Code'
fi
"$bt/apksigner" sign --ks "$key" --ks-pass "file:$pass" --ks-key-alias "$alias" --v4-signing-enabled false --out "$output" "$pack/aligned.apk"
"$bt/apksigner" verify --verbose --print-certs "$output"
"$bt/aapt2" dump badging "$output" | head -18
unzip -tq "$output"
