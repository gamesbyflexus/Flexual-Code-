#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd); cd "$root"
cache=$(realpath "${1:-.cache/flexual}"); base="$cache/flexual-base-1.0.0.exe"; overlay="$cache/studio-overlay"
# The 1.0 offline package supplies unchanged editor files. A full rebuild from
# upstream, without a nested installer, is also possible with build-windows.sh.
if [[ ! -f "$base" ]]; then
  echo 'Need the original Flexual 1.0 installer at' "$base" >&2; exit 1
fi
python flexual-src/appearance/apply.py "$cache/win/resources/app"
rm -rf "$overlay"; mkdir -p "$overlay"
(cd "$cache/win" && cp -r --parents resources/app/product.json resources/app/out/media/flexual-studio.svg resources/app/out/vs/workbench/workbench.desktop.main.{css,js} resources/app/extensions/theme-flexual "$overlay/")
makensis -V3 "-DOUT=$cache/studio-windows.exe" "-DICO=$root/assets/flexual.ico" "-DPAYLOAD=$overlay" "-DBASE_SETUP=$base" flexual-src/windows.nsi
python flexual-src/prepare-network.py "$cache"
makensis -V3 -DNETWORK=1 "-DOUT=$cache/studio-web-setup.exe" "-DICO=$root/assets/flexual.ico" "-DPAYLOAD=$cache/network-overlay" flexual-src/windows.nsi
7z t "$cache/studio-windows.exe"
7z t "$cache/studio-web-setup.exe"
