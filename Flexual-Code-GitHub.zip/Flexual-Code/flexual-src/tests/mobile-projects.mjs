import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
const cache=path.resolve(process.argv[2]??'.cache/flexual');
const {chromium}=createRequire(path.join(cache,'package.json'))('playwright');
const browser=await chromium.launch({executablePath:process.env.CHROMIUM??'/usr/bin/chromium',args:['--no-sandbox','--disable-gpu']});
const site={
 'sample/index.html':'<!doctype html><meta charset="utf-8"><link rel="stylesheet" href="assets/styles.css"><main id="target">Initial</main><script type="module" src="src/app.js"></script><script src="https://example.net/no-network.js"></script>',
 'sample/assets/styles.css':'main{color:#315fc1}',
 'sample/src/app.js':'import {title} from "./message.js"; document.querySelector("main").textContent=title;',
 'sample/src/message.js':'export const title="Flexual HTML/CSS/JS OK";',
 'sample/пустая/':'',
};
try{
 const p=await browser.newPage({viewport:{width:840,height:760}});
 await p.goto('http://127.0.0.1:8766/');
 await p.locator('.flexual-theme-flexual-night-json').waitFor();
 await p.waitForFunction(()=>window.FlexualDevice?.ready()&&typeof window.fflate==='object');
 const send=async(input,name)=>{
  await p.evaluate(({input,name})=>{
   const content=Object.fromEntries(Object.entries(input).map(([k,v])=>[k,fflate.strToU8(v)]));
   FlexualDevice.resetImport();const zip=fflate.zipSync(content);let bytes='';for(let i=0;i<zip.length;i+=8192)bytes+=String.fromCharCode(...zip.subarray(i,i+8192));
   FlexualDevice.importPart(btoa(bytes));FlexualDevice.finishProjectImport(name);
  },{input,name});
  await p.waitForFunction(()=>FlexualDevice.result());return p.evaluate(()=>FlexualDevice.result());
 };
 const exp=async(method,args)=>{
  await p.evaluate(({method,args})=>FlexualDevice[method](...args),{method,args});await p.waitForFunction(()=>FlexualDevice.result());
  return p.evaluate(()=>{const meta=FlexualDevice.result();if(!meta.ok)return{meta};const bytes=Uint8Array.from(atob(FlexualDevice.exportPart(0,meta.length)),s=>s.charCodeAt(0));
  const data=Object.fromEntries(Object.entries(fflate.unzipSync(bytes)).map(([k,v])=>[k,fflate.strFromU8(v)]));FlexualDevice.clearExport();return{meta,data,bytes:Array.from(bytes)};});
 };
 assert.equal((await send({'../outside.txt':'oops'},'bad.zip')).ok,false);
 assert.equal((await send({'thing':'a','thing/file.txt':'b'},'clash.zip')).ok,false);
 assert.equal((await send(Object.fromEntries(Array.from({length:501},(_,i)=>[`file${i}.txt`,''])),'many.zip')).ok,false);
 const imported=await send(site,'demo.zip');assert.deepEqual(imported,{ok:true,name:'demo',count:4});
 assert.equal((await send(site,'demo.zip')).name,'demo (2)');
 console.log('Nested paths, duplicate project names, unsafe paths and entry limits OK');
 await p.waitForFunction(()=>FlexualDevice.previewRevision()>0);
 const zip=await exp('prepareProjectExport',['demo']);assert.equal(zip.meta.name,'demo.zip');assert.equal(zip.data['sample/src/message.js'],site['sample/src/message.js']);assert.ok(Object.hasOwn(zip.data,'sample/пустая/'));
 assert.equal((await send(zip.data,'roundtrip.zip')).count,4);
 console.log('ZIP roundtrip preserves files, UTF-8 and empty directories');
 const snap=await exp('preparePreview',['demo','sample/index.html',true]);assert.equal(snap.meta.entry,'sample/index.html');assert.equal(snap.data['sample/src/app.js'],site['sample/src/app.js']);
 fs.writeFileSync(path.join(cache,'qa-site-snapshot.zip'),Buffer.from(snap.bytes));
 const view=await browser.newPage();const java=fs.readFileSync('flexual-src/android/SitePreview.java','utf8');const policy=java.match(/POLICY="([^"]+)"/)[1];let external=0;
 await view.route('**/*',r=>{const url=new URL(r.request().url());if(url.host!=='p-demo.flexual.invalid'){external++;return r.abort();}const name=decodeURIComponent(url.pathname.slice(1));const body=snap.data[name];return r.fulfill({status:body===undefined?404:200,headers:{'Content-Security-Policy':policy,'X-Content-Type-Options':'nosniff','Content-Type':name.endsWith('.js')?'application/javascript':name.endsWith('.css')?'text/css':'text/html'},body:body??''});});
 await view.goto('https://p-demo.flexual.invalid/sample/index.html');await view.getByText('Flexual HTML/CSS/JS OK').waitFor();assert.equal(await view.locator('main').evaluate(e=>getComputedStyle(e).color),'rgb(49, 95, 193)');assert.equal(external,0);
 console.log('Preview loads relative CSS and JavaScript modules; external script blocked');
 const revision=await p.evaluate(()=>FlexualDevice.previewRevision());
 await p.locator('.view-lines').first().click();await p.keyboard.press('Control+End');
 await p.evaluate(()=>{FlexualDevice.insertSymbol(';');FlexualDevice.insertSymbol('→');});
 await p.waitForFunction(()=>document.querySelector('.view-lines')?.innerText.includes(';'));
 const changed=await exp('prepareProjectExport',['roundtrip']);assert.match(changed.data['sample/index.html'],/;[\t ]+$/);
 await p.waitForFunction(r=>FlexualDevice.previewRevision()>r,revision);console.log('Symbol inserted into active editor, saved and noticed by preview revision');
 await p.reload();await p.waitForFunction(()=>window.FlexualDevice?.ready());const again=await exp('prepareProjectExport',['demo']);assert.equal(again.data['sample/index.html'],site['sample/index.html']);
 console.log('Workspace survives reload');
}finally{await browser.close();}
