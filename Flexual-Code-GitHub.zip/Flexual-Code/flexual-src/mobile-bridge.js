// Injected into the standalone Code - OSS module, whose lexical scope provides
// URI, buffer, and workbench services. Android only calls these named methods.
const flexualLimit=4*1024*1024;
const flexualRoot=A.from({scheme:"flexual",path:"/Workspace"});
let flexualFiles,flexualImport=[],flexualExport='',flexualResult=null;
function flexualReport(p){flexualResult=null;Promise.resolve().then(p).then(data=>{flexualResult={ok:true,...data}},e=>{flexualResult={ok:false,message:String(e.message||e)}});}
async function flexualCmd(id,...args){return (await mq.p).commands.executeCommand(id,...args);}
function flexualNotify(message){return mq.p.then(w=>w.window.showInformationMessage(message));}
const flexualWelcome='# Flexual Code\n\nВаше локальное рабочее пространство Code — OSS.\n\n- **Импорт** — копирует файл с устройства в рабочую область.\n- **Сохранить** — сохраняет изменения в приложении.\n- **Экспорт** — сохраняет копию открытого файла в выбранное место.\n\nФайлы рабочей области остаются на телефоне. Перед удалением приложения или очисткой его данных экспортируйте важные файлы.\n';
globalThis.FlexualDevice={
  ready:()=>!!flexualFiles&&!!document.querySelector('.monaco-workbench'),
  resetImport:()=>{flexualImport=[];flexualResult=null;return true},
  importPart:b64=>{flexualImport.push(b64);return true},
  finishImport:rawName=>flexualReport(async()=>{
    const name=String(rawName).replace(/[\\/\u0000-\u001f]/g,'_').trim().slice(0,155);
    if(!name||name==='.'||name==='..') throw Error('Некорректное имя файла.');
    const data=atob(flexualImport.join(''));flexualImport=[];
    if(data.length>flexualLimit)throw Error('Максимальный размер файла — 4 МБ.');
    let file=A.joinPath(flexualRoot,name),i=1,dot=name.lastIndexOf('.');
    while(await flexualFiles.exists(file)){file=A.joinPath(flexualRoot,dot>0?`${name.slice(0,dot)} (${i++})${name.slice(dot)}`:`${name} (${i++})`);}
    await flexualFiles.writeFile(file,Ve.wrap(Uint8Array.from(data,c=>c.charCodeAt(0))));
    await flexualCmd('vscode.open',file);
    return {name:file.path.split('/').pop()};
  }),
  save:()=>flexualReport(async()=>{await flexualCmd('workbench.action.files.save');return {};}),
  prepareExport:()=>flexualReport(async()=>{
    const editor=(await mq.p).flexualEditor;
    if(!editor.activeEditor?.resource)throw Error('Сначала откройте файл.');
    await flexualCmd('workbench.action.files.save');
    const file=editor.activeEditor?.resource;
    if(!file||file.scheme!=='flexual')throw Error('Откройте сохранённый файл из рабочей области.');
    const stat=await flexualFiles.stat(file);
    if(stat.size>flexualLimit)throw Error('Максимальный размер файла — 4 МБ.');
    const buffer=(await flexualFiles.readFile(file)).value.buffer;
    let str='';for(let i=0;i<buffer.length;i+=16384)str+=String.fromCharCode(...buffer.subarray(i,i+16384));
    flexualExport=btoa(str);return {name:file.path.split('/').pop(),length:flexualExport.length};
  }),
  exportPart:(start,end)=>flexualExport.slice(start,end),
  clearExport:()=>{flexualExport='';return true},
  result:()=>flexualResult,
  palette:()=>{flexualCmd('workbench.action.showCommands');return true},
  explorer:()=>{flexualToggleView('workbench.view.explorer');return true},
  search:()=>{flexualToggleView('workbench.view.search');return true},
  newFile:()=>{flexualCmd('workbench.view.explorer').then(()=>flexualCmd('explorer.newFile'));return true}
};

function flexualRegisterSearch(services){
  const search=services.get(yf),files=new x6e(flexualFiles);
  search.registerSearchResultProvider('flexual',0,files);
  search.registerSearchResultProvider('flexual',1,{
    getAIName:async()=>undefined,clearCache:async()=>{},
    async textSearch(query,progress,token){
      const content=query.contentPattern, results=[];
      const raw=content.isRegExp?content.pattern:content.pattern.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
      if(!raw)return {results,messages:[]};
      const re=new RegExp(content.isWordMatch?`\\b(?:${raw})\\b`:raw,content.isCaseSensitive?'g':'gi');
      const list=await files.fileSearch({...query,maxResults:undefined},token);
      let remaining=query.maxResults??2000;
      for(const {resource} of list.results){
        if(token?.isCancellationRequested||remaining<=0)break;
        let data;try{if((await flexualFiles.stat(resource)).size>flexualLimit)continue;data=(await flexualFiles.readFile(resource)).value.toString();}catch{continue;}
        if(data.includes('\u0000'))continue;
        const matches=[];let row=0;
        for(const line of data.split(/\r?\n/)){
          const ranges=[];re.lastIndex=0;
          for(const match of line.matchAll(re)){
            if(!match[0].length)continue;
            ranges.push(new kJt(row,match.index,row,match.index+match[0].length));
            if(--remaining<=0)break;
          }
          if(ranges.length)matches.push(new ade(line,ranges,query.previewOptions));
          if(remaining<=0)break;
          row++;
        }
        if(matches.length){const item={resource,results:matches};results.push(item);progress?.(item);}
      }
      return {results,messages:[],limitHit:remaining<=0};
    }
  });
}

function flexualToggleView(view){
  const panel=document.querySelector('.part.sidebar');
  if(panel?.offsetWidth&&panel.dataset.activeComposite===view)return flexualCmd('workbench.action.closeSidebar');
  return flexualCmd(view);
}
function flexualCompactStartup(editor){
  if(!matchMedia('(max-width: 600px)').matches)return;
  const close=()=>flexualCmd('workbench.action.closeSidebar');
  mq.p.then(close);
  editor.onDidActiveEditorChange(()=>{
    if(editor.activeEditor?.resource?.scheme==='flexual'&&document.querySelector('.part.sidebar')?.dataset.activeComposite==='workbench.view.explorer')close();
  });
}
