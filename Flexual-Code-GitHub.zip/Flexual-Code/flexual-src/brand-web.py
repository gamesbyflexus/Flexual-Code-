import json, shutil, sys, html
from pathlib import Path
from PIL import Image
from runpy import run_path
root=Path(__file__).resolve().parents[1]
cache=Path(sys.argv[1]); src=cache/'web'; dst=cache/'mobile-web'
if dst.exists(): shutil.rmtree(dst)
dst.mkdir()
for folder in ['out','resources']:
 shutil.copytree(src/folder,dst/folder,ignore=shutil.ignore_patterns('*.map','*.scpt','*.sh','server-main.js','server-cli.js','bootstrap-fork.js','agentHostMain.js','watcherMain.js','ptyHostMain.js'))
for ext in (src/'extensions').iterdir():
 package=ext/'package.json'
 if not package.exists(): continue
 data=json.loads(package.read_text())
 if (data.get('main') and not data.get('browser')) or (isinstance(data.get('browser'),str) and not (ext/data['browser']).exists() and not Path(str(ext/data['browser'])+'.js').exists()) or ext.name in {'mermaid-markdown-features','github-authentication','microsoft-authentication','configuration-editing'}: continue
 shutil.copytree(ext,dst/'extensions'/ext.name,ignore=shutil.ignore_patterns('*.map'))
for pkg in ['vscode-oniguruma','vscode-textmate','@vscode/tree-sitter-wasm','@vscode/vscode-languagedetection','katex']:
 shutil.copytree(src/'node_modules'/pkg,dst/'node_modules'/pkg,ignore=shutil.ignore_patterns('*.map'))
if (src/'extensions/node_modules/typescript').exists():
 shutil.copytree(src/'extensions/node_modules/typescript',dst/'extensions/node_modules/typescript',ignore=shutil.ignore_patterns('*.map'))
for f in ['LICENSE.txt','ThirdPartyNotices.txt']:
 shutil.copy(cache/'win/resources/app'/f,dst/f)
for svg in ['out/media/code-icon.svg','out/media/letterpress-dark.svg','out/media/letterpress-light.svg','out/media/letterpress-hcLight.svg','out/media/letterpress-hcDark.svg']:
 shutil.copy(root/'assets/flexual.svg',dst/svg)
for size in [192,512]:
 Image.open(root/'assets/flexual.png').resize((size,size),Image.Resampling.LANCZOS).save(dst/f'resources/server/code-{size}.png')
shutil.copy(root/'assets/flexual.ico',dst/'resources/server/favicon.ico')
for name in ['fflate-0.8.2.js','fflate-LICENSE.txt']: shutil.copy(root/'flexual-src/vendor'/name,dst/name)
manifest=dst/'resources/server/manifest.json'; manifest.write_text(json.dumps({'name':'Flexual Code','short_name':'Flexual','start_url':'/','display':'standalone','theme_color':'#111a2c','background_color':'#151a26','icons':[{'src':f'code-{s}.png','sizes':f'{s}x{s}','type':'image/png'} for s in [192,512]]}))
appearance=run_path(root/'flexual-src/appearance/apply.py'); theme=appearance['init'](dst,True)
js=dst/'out/vs/code/browser/workbench/workbench.js'; s=js.read_text()
def replace(a,b):
 global s
 if s.count(a)!=1: raise ValueError(f'{a!r}: expected one match, got {s.count(a)}')
 s=s.replace(a,b)
replace('t.registerProvider(Z.vscodeUserData,p),pg.supported(gt)', '''t.registerProvider(Z.vscodeUserData,p);
    let fxDB=await $ct.create("flexual-workspace-v1",1,["files"]);
    this.onWillShutdownDisposables.add(j(()=>fxDB.close()));
    let fx=new HUt("flexual",fxDB,"files",!0);this.indexedDBFileSystemProviders.push(fx);t.registerProvider("flexual",fx);flexualFiles=t;t.onDidFilesChange(e=>{if([...(e.rawAdded??[]),...(e.rawUpdated??[]),...(e.rawDeleted??[])].some(u=>u.scheme==="flexual"))fxProjectRevision++;});
    await t.createFolder(flexualRoot);
    if(!localStorage.getItem("flexual-initialized-v1")){
      const f=A.joinPath(flexualRoot,"README.md");if(!await t.exists(f))await t.writeFile(f,Ve.fromString(flexualWelcome));
      localStorage.setItem("flexual-initialized-v1","yes");
    }
    pg.supported(gt)''')
replace('i.invokeFunction(n=>{let r=n.get(ye),a=n.get(jo)', 'i.invokeFunction(n=>{flexualRegisterSearch(n);flexualCompactStartup(n.get(de));let r=n.get(ye),a=n.get(jo)')
replace('window:{withProgress:(k,_)=>p.withProgress(k,_)','flexualEditor:n.get(de),window:{withProgress:(k,_)=>p.withProgress(k,_)')
replace('this.builtinExtensionsPromises=c.map(async l=>','c.push('+json.dumps({'extensionPath':'theme-flexual','packageJSON':json.loads((theme/'package.json').read_text())},separators=(',',':'))+');this.builtinExtensionsPromises=c.filter(l=>'+json.dumps(sorted(x.name for x in (dst/'extensions').iterdir()),ensure_ascii=True)+'.includes(l.extensionPath)).map(async l=>')
replace('(function(){gt.document.getElementById("vscode-startup-fallback")', (root/'flexual-src/mobile-bridge.js').read_text()+'\n'+(root/'flexual-src/mobile-projects.js').read_text()+'\n(function(){gt.document.getElementById("vscode-startup-fallback")')
s=s.replace('sourceMappingURL=https://github.com/VSCodium/sourcemaps/', 'flexualUpstreamSourceMap=https://github.com/VSCodium/sourcemaps/')
js.write_text(s)
cfg={'_wrapWebWorkerExtHostInIframe':False,'enableWorkspaceTrust':True,'folderUri':{'scheme':'flexual','path':'/Workspace'},'callbackRoute':'/out/vs/code/browser/workbench/callback.html','productConfiguration':{'nameShort':'Flexual Code','nameLong':'Flexual Code','applicationName':'flexual','embedderIdentifier':'flexual-mobile','urlProtocol':'flexual-code','extensionsGallery':None,'webEndpointUrlTemplate':None,'webviewContentExternalBaseUrlTemplate':None},'configurationDefaults':{'window.title':'${activeEditorShort}${separator}Flexual Code','workbench.startupEditor':'none','workbench.colorTheme':'Default Dark Modern','workbench.layoutControl.enabled':False,'workbench.tips.enabled':False,'editor.minimap.enabled':False,'editor.wordWrap':'on','editor.fontSize':13,'editor.quickSuggestions':{'other':'on','comments':'off','strings':'off'},'chat.disableAIFeatures':True}}
cfg['configurationDefaults'].update(appearance['common'])
cfg['configurationDefaults'].update({'workbench.activityBar.location':'hidden','workbench.sideBar.location':'left','editor.fontSize':13,'editor.lineHeight':22,'chat.disableAIFeatures':True})
template=(src/'out/vs/code/browser/workbench/workbench.html').read_text()
for k,v in {'WORKBENCH_SCRIPT_NONCE':'flexual-static','WORKBENCH_WEB_BASE_URL':'/ide','WORKBENCH_AUTH_SESSION':'','WORKBENCH_NLS_FALLBACK_URL':'/ide/out/nls.messages.js','WORKBENCH_WEB_CONFIGURATION':html.escape(json.dumps(cfg,separators=(',',':')),quote=True)}.items():
 template=template.replace('{{'+k+'}}',v)
template=template.replace('\t<!-- attempt to load NLS messages in case non-english -->\n\t<script type="module" src="{{WORKBENCH_NLS_URL}}"></script>','')
template=template.replace('<meta charset="utf-8" />','<meta charset="utf-8" /><title>Flexual Code</title>')
template=template.replace('content="Code">','content="Flexual Code">')
template=template.replace('The editor failed to load','Не удалось запустить Flexual Code').replace('A proxy, browser extension or content filter may be blocking or modifying this page\'s scripts. Check the browser developer tools console for Content Security Policy errors.','Обновите Android System WebView и перезапустите приложение.')
template=template.replace('<script type="module" src="/ide/out/vs/code/browser/workbench/workbench.js"></script>', '<script src="/ide/fflate-0.8.2.js"></script>\n<script type="module" src="/ide/out/vs/code/browser/workbench/workbench.js"></script>')
(dst/'index.html').write_text(template)
