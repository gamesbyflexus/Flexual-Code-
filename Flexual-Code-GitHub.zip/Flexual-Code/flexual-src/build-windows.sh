#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
root=$PWD; cache=$(realpath "${1:-.cache/flexual}"); mkdir -p downloads
if [[ -f "$cache/win/VSCodium.exe" ]]; then
  node flexual-src/brand-win.mjs "$cache"
  python flexual-src/brand-win.py "$cache/win"
fi
python flexual-src/appearance/apply.py "$cache/win/resources/app"
makensis -V3 "-DOUT=$root/downloads/Flexual-Code-Setup-x64.exe" "-DICO=$root/assets/flexual.ico" "-DPAYLOAD=$cache/win" flexual-src/windows.nsi
