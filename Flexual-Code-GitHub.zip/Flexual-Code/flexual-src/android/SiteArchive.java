package app.flexual.code;

import java.util.*;
import java.io.*;
import java.util.zip.*;

final class SiteArchive {
  static final int LIMIT=16*1024*1024;
  static Map<String, byte[]> read(byte[] zip) throws IOException {
    if(zip.length>LIMIT+131072)throw new IOException("Проект слишком большой");
    Map<String,byte[]> files=new HashMap<>();int total=0,count=0;
    try(ZipInputStream in=new ZipInputStream(new ByteArrayInputStream(zip))){
      byte[] buffer=new byte[16384];
      for(ZipEntry entry;(entry=in.getNextEntry())!=null;){
        if(++count>500||entry.isDirectory()||!valid(entry.getName())||files.containsKey(entry.getName()))throw new IOException("Некорректный снимок проекта");
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        for(int n;(n=in.read(buffer))!=-1;){if((total+=n)>LIMIT)throw new IOException("Проект слишком большой");out.write(buffer,0,n);}
        files.put(entry.getName(),out.toByteArray());in.closeEntry();
      }
    }
    return Collections.unmodifiableMap(files);
  }
  private static boolean valid(String s){
    if(s.isEmpty()||s.length()>480||s.indexOf('\\')>=0||s.indexOf(':')>=0)return false;
    for(int i=0;i<s.length();i++)if(s.charAt(i)<32||s.charAt(i)==127)return false;
    for(String part:s.split("/",-1))if(part.isEmpty()||part.equals(".")||part.equals(".."))return false;
    return true;
  }
}
