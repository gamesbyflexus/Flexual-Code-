package app.flexual.code;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.webkit.*;
import android.view.ViewGroup;
import java.io.*;
import java.util.*;

/** Isolated, read-only local web preview. No bridge, no app-origin access, no network. */
final class SitePreview {
  private static final String POLICY="default-src 'none'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; media-src 'self' blob:; connect-src 'self'; form-action 'none'; base-uri 'self'; worker-src 'none'; frame-src 'none'; object-src 'none'; frame-ancestors 'none'";
  final WebView view;
  private final String host="p-"+UUID.randomUUID().toString()+".flexual.invalid";
  private volatile Map<String,byte[]> files=Collections.emptyMap();
  SitePreview(Context context,Runnable crash){
    view=new WebView(context);view.setBackgroundColor(Color.WHITE);
    WebSettings s=view.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(false);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setSupportMultipleWindows(false);s.setJavaScriptCanOpenWindowsAutomatically(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setMediaPlaybackRequiresUserGesture(true);s.setCacheMode(WebSettings.LOAD_NO_CACHE);s.setGeolocationEnabled(false);
    view.setDownloadListener((url,agent,disposition,mime,length)->{});
    view.setWebChromeClient(new WebChromeClient(){
      @Override public void onPermissionRequest(PermissionRequest r){r.deny();}
      @Override public boolean onJsAlert(WebView v,String u,String m,JsResult r){r.cancel();return true;}
      @Override public boolean onJsConfirm(WebView v,String u,String m,JsResult r){r.cancel();return true;}
      @Override public boolean onJsPrompt(WebView v,String u,String m,String d,JsPromptResult r){r.cancel();return true;}
    });
    view.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !local(r.getUrl());}
      @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){
        if(!local(r.getUrl())||!"GET".equals(r.getMethod()))return error(403,"Forbidden");
        String p=r.getUrl().getPath();if(p==null||!p.startsWith("/"))return error(404,"Not Found");
        p=p.substring(1);Map<String,byte[]> snapshot=files;
        byte[] bytes=snapshot.get(p);if(bytes==null&&(p.isEmpty()||p.endsWith("/"))){p+="index.html";bytes=snapshot.get(p);}
        if(bytes==null)return error(404,"Not Found");
        Map<String,String> h=new HashMap<>();h.put("Content-Security-Policy",POLICY);h.put("Cache-Control","no-store");h.put("X-Content-Type-Options","nosniff");h.put("Referrer-Policy","no-referrer");
        String type=MainActivity.type(p.toLowerCase(Locale.ROOT));String charset=type.startsWith("text/")||type.equals("application/javascript")||type.equals("application/json")?"UTF-8":null;
        return new WebResourceResponse(type,charset,200,"OK",h,new ByteArrayInputStream(bytes));
      }
      @Override public boolean onRenderProcessGone(WebView v,RenderProcessGoneDetail detail){crash.run();return true;}
    });
  }
  private boolean local(Uri u){return "https".equals(u.getScheme())&&host.equals(u.getHost())&&(u.getPort()==-1||u.getPort()==443);}
  private static WebResourceResponse error(int code,String label){return new WebResourceResponse("text/plain","UTF-8",code,label,Collections.singletonMap("Cache-Control","no-store"),new ByteArrayInputStream(new byte[0]));}
  void display(Map<String,byte[]> map,String entry){
    files=map;Uri.Builder url=new Uri.Builder().scheme("https").authority(host);
    for(String part:entry.split("/"))url.appendPath(part);
    view.stopLoading();view.loadUrl(url.build().toString());
  }
  void destroy(){files=Collections.emptyMap();view.stopLoading();if(view.getParent() instanceof ViewGroup)((ViewGroup)view.getParent()).removeView(view);view.destroy();}
}
