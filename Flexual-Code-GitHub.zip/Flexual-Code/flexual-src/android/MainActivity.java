package app.flexual.code;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.Context;
import android.content.res.Configuration;
import android.view.inputmethod.InputMethodManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.*;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public final class MainActivity extends Activity {
  private static final String HOST="appassets.androidplatform.net", ORIGIN="https://"+HOST;
  private static final int IMPORT=40, EXPORT=41, IMPORT_ZIP=42, LIMIT=4*1024*1024, CHUNK=65536;
  private final ExecutorService worker=Executors.newSingleThreadExecutor();
  private WebView web;
  private LinearLayout stage, previewPanel, dock;
  private HorizontalScrollView symbols;
  private SitePreview preview;
  private String previewProject="", previewEntry="";
  private int previewRevision=-1, previewSession;
  private boolean keyboard;
  private byte[] exportBytes;
  private boolean busy;
  private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
  private static int color(String s){return Color.parseColor(s);}
  @Override public void onCreate(Bundle saved){
    super.onCreate(saved);
    getWindow().setStatusBarColor(color("#0C0D1A"));getWindow().setNavigationBarColor(color("#0C0D1A"));
    LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setBackgroundColor(color("#121222"));
    LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(13),0,dp(7),0);bar.setBackgroundColor(color("#0C0D1A"));
    layout.addView(bar,new LinearLayout.LayoutParams(-1,dp(59)));
    ImageView icon=new ImageView(this);icon.setImageResource(R.drawable.flexual);bar.addView(icon,new LinearLayout.LayoutParams(dp(31),dp(31)));
    LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);brand.setPadding(dp(9),0,dp(5),0);
    TextView title=new TextView(this);title.setText("Flexual Code");title.setSingleLine();title.setEllipsize(android.text.TextUtils.TruncateAt.END);title.setTextSize(16);title.setTextColor(color("#F0EEFF"));title.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));brand.addView(title);
    TextView edition=new TextView(this);edition.setText("M O B I L E   S T U D I O");edition.setTextColor(color("#B8A5F1"));edition.setTextSize(8);edition.setSingleLine();edition.setTypeface(Typeface.MONOSPACE);brand.addView(edition);bar.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
    addButton(bar,"Импорт файла",0,()->pick());addButton(bar,"Сохранить файл",1,()->action("save",true));addButton(bar,"Экспорт файла",2,()->export());
    View line=new View(this);line.setBackgroundColor(color("#2C2948"));layout.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
    stage=new LinearLayout(this);layout.addView(stage,new LinearLayout.LayoutParams(-1,0,1));
    web=new WebView(this);web.setBackgroundColor(color("#121222"));stage.addView(web,new LinearLayout.LayoutParams(-1,-1));
    web.setOnFocusChangeListener((v,focused)->updateControls());
    symbols=makeSymbols();symbols.setVisibility(View.GONE);layout.addView(symbols,new LinearLayout.LayoutParams(-1,dp(42)));
    View divider=new View(this);divider.setBackgroundColor(color("#2C2948"));layout.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
    dock=new LinearLayout(this);dock.setGravity(Gravity.CENTER_VERTICAL);dock.setPadding(dp(7),dp(6),dp(7),dp(6));dock.setBackgroundColor(color("#100F20"));
    addDock(dock,"Файлы","▱",()->action("explorer",false));addDock(dock,"Поиск","⌕",()->action("search",false));addDock(dock,"Сайт","◫",()->togglePreview());addDock(dock,"Ещё","•••",()->menu());
    layout.addView(dock,new LinearLayout.LayoutParams(-1,dp(53)));
    layout.getViewTreeObserver().addOnGlobalLayoutListener(()->{
      WindowInsets insets=layout.getRootWindowInsets();
      boolean shown;
      if(android.os.Build.VERSION.SDK_INT>=30&&insets!=null)shown=insets.isVisible(WindowInsets.Type.ime());
      else{Rect r=new Rect();layout.getWindowVisibleDisplayFrame(r);shown=layout.getRootView().getHeight()-r.bottom>dp(135);}
      if(shown!=keyboard){keyboard=shown;updateControls();}
    });
    WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setSupportMultipleWindows(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setMediaPlaybackRequiresUserGesture(true);
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !local(r.getUrl());}
      @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){return serve(r);}
      @Override public boolean onRenderProcessGone(WebView v,RenderProcessGoneDetail d){stage.removeView(v);v.destroy();web=null;recreate();return true;}
    });
    ServiceWorkerController.getInstance().setServiceWorkerClient(new ServiceWorkerClient(){@Override public WebResourceResponse shouldInterceptRequest(WebResourceRequest r){return serve(r);}});
    setContentView(layout);web.loadUrl(ORIGIN+"/");
  }
  private WebResourceResponse serve(WebResourceRequest r){
    Uri uri=r.getUrl();if(!local(uri)||!"GET".equals(r.getMethod()))return error(403,"Forbidden");
    String p=uri.getPath();if(p==null)return error(404,"Not Found");
    if(p.equals("/")||p.equals("/index.html"))p="/ide/index.html";
    if(!p.startsWith("/ide/")||p.indexOf('\\')>=0||Arrays.asList(p.split("/",-1)).contains(".."))return error(404,"Not Found");
    try{
      String file=p.substring(1);String mime=type(file);
      Map<String,String> headers=new HashMap<>();headers.put("Cache-Control","no-store");headers.put("X-Content-Type-Options","nosniff");
      return new WebResourceResponse(mime,(mime.startsWith("text/")||mime.equals("application/javascript")||mime.equals("application/json"))?"UTF-8":null,200,"OK",headers,getAssets().open(file));
    }catch(IOException e){return error(404,"Not Found");}
  }
  private static boolean local(Uri u){return "https".equals(u.getScheme())&&HOST.equals(u.getHost())&&(u.getPort()==-1||u.getPort()==443);}
  private static WebResourceResponse error(int c,String s){return new WebResourceResponse("text/plain","UTF-8",c,s,Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));}
  static String type(String f){
    if(f.endsWith(".js")||f.endsWith(".mjs"))return "application/javascript";if(f.endsWith(".html")||f.endsWith(".htm"))return "text/html";if(f.endsWith(".css"))return "text/css";if(f.endsWith(".json"))return "application/json";if(f.endsWith(".wasm"))return "application/wasm";if(f.endsWith(".svg"))return "image/svg+xml";if(f.endsWith(".md"))return "text/plain";int dot=f.lastIndexOf('.');String mime=dot<0?null:MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.substring(dot+1));return mime!=null?mime:"application/octet-stream";
  }
  private void addButton(LinearLayout bar,String desc,int shape,Runnable action){
    View v=new View(this){
      final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
      @Override protected void onDraw(Canvas c){
        super.onDraw(c);c.save();c.translate((getWidth()-dp(22))/2f,(getHeight()-dp(22))/2f);c.scale(dp(22)/24f,dp(22)/24f);
        p.setColor(color("#BDB3E1"));p.setStrokeWidth(1.7f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);p.setStyle(Paint.Style.STROKE);
        if(shape==3){p.setStyle(Paint.Style.FILL);for(int i=5;i<=19;i+=7)c.drawCircle(i,12,1.45f,p);}
        else if(shape==1){c.drawRoundRect(4,3,20,21,2,2,p);c.drawRect(8,3,16,8,p);c.drawRoundRect(8,13,16,21,1,1,p);}
        else{c.drawLine(5,16,5,20,p);c.drawLine(5,20,19,20,p);c.drawLine(19,20,19,16,p);
          if(shape==0){c.drawLine(12,3,12,15,p);c.drawLine(8,11,12,15,p);c.drawLine(16,11,12,15,p);}
          else{c.drawLine(12,4,12,15,p);c.drawLine(8,8,12,4,p);c.drawLine(16,8,12,4,p);}}
        c.restore();
      }
    };
    v.setBackground(new RippleDrawable(ColorStateList.valueOf(color("#3F365F")),null,new ColorDrawable(Color.WHITE)));v.setContentDescription(desc);v.setTooltipText(desc);v.setFocusable(true);v.setOnClickListener(w->action.run());bar.addView(v,new LinearLayout.LayoutParams(dp(45),-1));
  }
  private void addDock(LinearLayout dock,String label,String glyph,Runnable action){
    TextView item=new TextView(this);item.setText(glyph+"  "+label);item.setGravity(Gravity.CENTER);item.setTextColor(color("#DBD0F8"));item.setSingleLine();item.setTextSize(11);item.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
    android.graphics.drawable.GradientDrawable box=new android.graphics.drawable.GradientDrawable();box.setCornerRadius(dp(8));box.setColor(color("#1D1B32"));box.setStroke(dp(1),color("#312B4B"));
    item.setBackground(new RippleDrawable(ColorStateList.valueOf(color("#534676")),box,null));item.setContentDescription(label);item.setFocusable(true);item.setOnClickListener(v->action.run());
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(dp(3),0,dp(3),0);dock.addView(item,lp);
  }
  private HorizontalScrollView makeSymbols(){
    HorizontalScrollView scroller=new HorizontalScrollView(this);scroller.setFillViewport(false);scroller.setHorizontalScrollBarEnabled(false);scroller.setBackgroundColor(color("#141326"));
    LinearLayout keys=new LinearLayout(this);keys.setGravity(Gravity.CENTER_VERTICAL);keys.setPadding(dp(4),dp(3),dp(4),dp(3));scroller.addView(keys,new android.widget.FrameLayout.LayoutParams(-2,-1));
    for(String value:new String[]{"→","{","}","[","]","(",")",";","=","/","\\","<",">",":","\"","'","`","_","+","-","*","!","&","|"}){
      TextView key=new TextView(this);key.setText(value);key.setTextSize(16);key.setTypeface(Typeface.MONOSPACE);key.setGravity(Gravity.CENTER);key.setTextColor(color("#E2D8FF"));key.setFocusable(false);key.setContentDescription(value.equals("→")?"Отступ":value);
      android.graphics.drawable.GradientDrawable background=new android.graphics.drawable.GradientDrawable();background.setCornerRadius(dp(6));background.setColor(color("#25213B"));
      key.setBackground(new RippleDrawable(ColorStateList.valueOf(color("#534676")),background,null));
      key.setOnClickListener(v->device("insertSymbol("+JSONObject.quote(value)+")",null));
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(37),-1);lp.setMargins(dp(2),0,dp(2),0);keys.addView(key,lp);
    }return scroller;
  }
  private void updateControls(){
    if(dock==null||symbols==null)return;
    dock.setVisibility(keyboard?View.GONE:View.VISIBLE);
    symbols.setVisibility(keyboard&&web!=null&&web.getVisibility()==View.VISIBLE&&web.hasFocus()?View.VISIBLE:View.GONE);
  }
  private void menu(){
    String[] choices={"Импорт проекта ZIP","Экспорт проекта ZIP","Создать файл","Палитра команд","О приложении"};
    new AlertDialog.Builder(this).setTitle("Flexual Code").setItems(choices,(d,i)->{
      if(i==0)pick(IMPORT_ZIP);else if(i==1)chooseProjectExport();else if(i==2)action("newFile",false);else if(i==3)action("palette",false);else about();
    }).show();
  }
  private void about(){new AlertDialog.Builder(this).setTitle("Flexual Code 1.2").setMessage("Офлайн-редактор на базе Code — OSS. ZIP-проекты, предпросмотр HTML / CSS / JavaScript и панель символов. Терминал и настольные расширения недоступны. Перед удалением приложения экспортируйте важные файлы.\n\nЛицензии Code — OSS и fflate входят в APK.").setPositiveButton("Закрыть",null).show();}
  private void toast(String text){if(!isFinishing())Toast.makeText(this,text,Toast.LENGTH_SHORT).show();}
  private void eval(String script,ValueCallback<String> cb){if(web==null){if(cb!=null)cb.onReceiveValue("null");return;}web.evaluateJavascript(script,cb);}
  private void device(String expr,ValueCallback<String> cb){eval("window.FlexualDevice ? FlexualDevice."+expr+" : null",cb);}
  private void ready(Runnable next){if(busy){toast("Дождитесь окончания операции");return;}device("ready()",s->{if("true".equals(s))next.run();else toast("Редактор ещё загружается");});}
  private void action(String method,boolean wait){ready(()->{if(wait)busy=true;device(method+"()",s->{if(wait)poll(0,r->{busy=false;toast("Сохранено");});});});}
  private void pick(){pick(IMPORT);}
  private void pick(int request){ready(()->{
    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");
    try{startActivityForResult(i,request);}catch(Exception e){toast("Не найден системный выбор файлов");}
  });}
  private void export(){ready(()->{
    busy=true;device("prepareExport()",s->poll(0,r->transfer(r,LIMIT,b->writeExport(r.optString("name"),"application/octet-stream",b))));
  });}
  private void chooseProjectExport(){ready(()->{
    busy=true;device("projectList()",v->poll(0,r->{busy=false;JSONArray list=r.optJSONArray("projects");
      int size=list==null?0:list.length();String[] choices=new String[size+1];choices[0]="Вся рабочая область";
      for(int i=0;i<size;i++)choices[i+1]=list.optString(i);
      new AlertDialog.Builder(this).setTitle("Что экспортировать в ZIP?").setItems(choices,(d,i)->exportProject(i==0?"":choices[i])).show();
    }));
  });}
  private void exportProject(String project){ready(()->{
    busy=true;device("prepareProjectExport("+JSONObject.quote(project)+")",v->poll(0,r->transfer(r,SiteArchive.LIMIT+131072,b->writeExport(r.optString("name"),"application/zip",b))));
  });}
  private void writeExport(String name,String type,byte[] bytes){
    try{exportBytes=bytes;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(type);i.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(i,EXPORT);}catch(Exception e){exportBytes=null;toast("Не удалось открыть окно экспорта");}
  }
  @Override protected void onActivityResult(int req,int result,Intent data){
    super.onActivityResult(req,result,data);if(result!=RESULT_OK||data==null||data.getData()==null){if(req==EXPORT)exportBytes=null;return;}
    final Uri uri=data.getData();
    if(req==IMPORT||req==IMPORT_ZIP){busy=true;worker.execute(()->{try{
      String name="imported.txt";try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst()&&c.getString(0)!=null)name=c.getString(0);}
      final boolean zip=req==IMPORT_ZIP||name.toLowerCase(Locale.ROOT).endsWith(".zip");int limit=zip?SiteArchive.LIMIT+131072:LIMIT;
      byte[] bytes;try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){
        if(in==null)throw new IOException("Не удалось открыть файл");byte[] buffer=new byte[16384];for(int n;(n=in.read(buffer))!=-1;){if(out.size()+n>limit)throw new IOException(zip?"Архив слишком большой":"Максимальный размер файла — 4 МБ");out.write(buffer,0,n);}bytes=out.toByteArray();}
      final String file=name,b64=Base64.encodeToString(bytes,Base64.NO_WRAP);runOnUiThread(()->device("resetImport()",s->push(file,b64,0,zip)));
    }catch(Exception e){runOnUiThread(()->{busy=false;toast(e.getMessage()==null?"Не удалось прочитать файл":e.getMessage());});}});}
    if(req==EXPORT&&exportBytes!=null){final byte[] b=exportBytes;exportBytes=null;worker.execute(()->{
      try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException();out.write(b);runOnUiThread(()->toast("Файл экспортирован"));}
      catch(IOException e){runOnUiThread(()->toast("Не удалось сохранить файл"));}
    });}
  }
  private interface Result{void accept(JSONObject obj);}
  private void poll(int attempt,Result next){device("result()",s->{
    if(s!=null&&s.startsWith("{")){try{JSONObject obj=new JSONObject(s);if(obj.optBoolean("ok")){next.accept(obj);return;}busy=false;toast(obj.optString("message","Не удалось выполнить действие"));return;}catch(JSONException ignored){}}
    if(attempt>=100||web==null){busy=false;toast("Редактор не ответил. Повторите попытку");return;}web.postDelayed(()->poll(attempt+1,next),100);
  });}
  private void push(String name,String data,int index,boolean zip){
    if(isFinishing())return;
    if(index>=data.length()){device((zip?"finishProjectImport(":"finishImport(")+JSONObject.quote(name)+")",s->poll(0,r->{busy=false;toast((zip?"Проект импортирован: ":"Импортировано: ")+r.optString("name"));}));return;}
    int end=Math.min(index+CHUNK,data.length());device("importPart("+JSONObject.quote(data.substring(index,end))+")",s->{if("true".equals(s))push(name,data,end,zip);else{busy=false;toast("Редактор недоступен");}});
  }
  private interface Bytes{void accept(byte[] data);}
  private void transfer(JSONObject meta,int limit,Bytes done){
    int total=meta.optInt("length",-1);
    if(total<0||total>((limit+2)/3)*4){busy=false;device("clearExport()",null);toast("Данные слишком велики");return;}
    pull(total,0,new StringBuilder(Math.min(total,1048576)),done);
  }
  private void pull(int total,int index,StringBuilder out,Bytes done){
    if(isFinishing())return;
    if(index>=total){
      device("clearExport()",null);String b64=out.toString();worker.execute(()->{
        try{byte[] data=Base64.decode(b64,Base64.NO_WRAP);runOnUiThread(()->{busy=false;if(!isFinishing())done.accept(data);});}
        catch(IllegalArgumentException e){runOnUiThread(()->{busy=false;toast("Не удалось получить содержимое");});}
      });return;
    }
    int end=Math.min(index+CHUNK,total);device("exportPart("+index+","+end+")",s->{try{String part=(String)new JSONTokener(s).nextValue();if(part.length()!=end-index)throw new IOException();out.append(part);pull(total,end,out,done);}catch(Exception e){busy=false;device("clearExport()",null);toast("Не удалось получить содержимое");}});
  }
  private void togglePreview(){if(preview!=null){closePreview();return;}ready(()->requestPreview(false,true));}
  private void requestPreview(boolean keep,boolean save){
    if(busy){if(save)toast("Дождитесь окончания операции");return;}
    final int session=previewSession;
    final String target=keep?JSONObject.quote(previewProject)+","+JSONObject.quote(previewEntry):"null,null";
    busy=true;device("preparePreview("+target+","+save+")",x->poll(0,r->transfer(r,SiteArchive.LIMIT+131072,data->{
      busy=true;worker.execute(()->{
        try{Map<String,byte[]> pages=SiteArchive.read(data);String entry=r.getString("entry");if(!pages.containsKey(entry))throw new IOException();
          runOnUiThread(()->{busy=false;if(session!=previewSession||isFinishing())return;
            previewProject=r.optString("project");previewEntry=entry;previewRevision=r.optInt("revision",0);openPreview(pages,entry);
          });
        }catch(Exception e){runOnUiThread(()->{busy=false;if(session==previewSession)toast("Не удалось открыть предпросмотр");});}
      });
    })));
  }
  private void openPreview(Map<String,byte[]> pages,String entry){
    if(preview==null){
      previewPanel=new LinearLayout(this);previewPanel.setOrientation(LinearLayout.VERTICAL);previewPanel.setBackgroundColor(color("#121222"));
      LinearLayout controls=new LinearLayout(this);controls.setPadding(dp(4),dp(4),dp(4),dp(4));controls.setBackgroundColor(color("#18172D"));
      addDock(controls,"К коду","‹",()->closePreview());addDock(controls,"Обновить","↻",()->requestPreview(true,true));
      previewPanel.addView(controls,new LinearLayout.LayoutParams(-1,dp(47)));
      preview=new SitePreview(this,()->{closePreview();toast("Предпросмотр закрыт: страница перестала отвечать");});
      previewPanel.addView(preview.view,new LinearLayout.LayoutParams(-1,0,1));stage.addView(previewPanel);
      layoutPreview();if(web.getVisibility()!=View.VISIBLE)((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(stage.getWindowToken(),0);
      watchPreview(previewSession);
    }
    preview.display(pages,entry);
  }
  private void watchPreview(int session){
    stage.postDelayed(()->{
      if(preview==null||previewSession!=session||isFinishing())return;
      if(!busy)device("previewRevision()",v->{try{int rev=Integer.parseInt(v);if(preview!=null&&previewSession==session&&rev!=previewRevision&&!busy){previewRevision=rev;requestPreview(true,false);}}catch(Exception ignored){}});
      watchPreview(session);
    },1350);
  }
  private void layoutPreview(){
    if(web==null)return;
    if(previewPanel==null){web.setVisibility(View.VISIBLE);web.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));updateControls();return;}
    boolean split=getResources().getConfiguration().screenWidthDp>=650;
    web.setVisibility(split?View.VISIBLE:View.GONE);web.setLayoutParams(split?new LinearLayout.LayoutParams(0,-1,1):new LinearLayout.LayoutParams(-1,-1));
    previewPanel.setLayoutParams(split?new LinearLayout.LayoutParams(0,-1,1):new LinearLayout.LayoutParams(-1,-1));updateControls();
  }
  private void closePreview(){
    previewSession++;if(preview!=null){preview.destroy();preview=null;}
    if(previewPanel!=null){stage.removeView(previewPanel);previewPanel=null;}layoutPreview();
  }
  @Override public void onConfigurationChanged(Configuration config){super.onConfigurationChanged(config);layoutPreview();}
  @Override public void onBackPressed(){if(preview!=null)closePreview();else super.onBackPressed();}
  @Override protected void onDestroy(){previewSession++;if(preview!=null){preview.destroy();preview=null;}worker.shutdownNow();if(web!=null){if(web.getParent() instanceof ViewGroup)((ViewGroup)web.getParent()).removeView(web);web.destroy();web=null;}super.onDestroy();}
}
