#!/usr/bin/env python3
"""Build a static download site for deployment at a GitHub Pages project path."""
import argparse
import json
from pathlib import Path
import re
import shutil
from urllib.parse import quote, urlsplit

ROOT = Path(__file__).resolve().parent.parent


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', required=True, help='OWNER/REPO')
    p.add_argument('--server', default='https://github.com')
    p.add_argument('--out', type=Path, default=ROOT / '_site')
    args = p.parse_args()
    if not re.fullmatch(r'[a-zA-Z0-9-]+/[a-zA-Z0-9_.-]+', args.repo):
        p.error('Use OWNER/REPO for --repo')
    server = urlsplit(args.server)
    if server.scheme != 'https' or not server.hostname or server.username or server.password or server.path.rstrip('/') or server.query or server.fragment:
        p.error('Use an HTTPS origin for --server')
    config = json.loads((ROOT / 'release.json').read_text(encoding='utf-8'))
    if not re.fullmatch(r'v\d+\.\d+\.\d+(?:[-.][a-zA-Z0-9.-]+)?', config['tag']):
        p.error('Unexpected release tag')
    template = (ROOT / 'index.html').read_text(encoding='utf-8')
    linked = set(re.findall(r'href="/downloads/([a-zA-Z0-9_.-]+)"', template))
    if linked != set(config['assets']):
        p.error('The download links in index.html must match release.json')
    base = f'{args.server.rstrip("/")}/{args.repo}/releases/download/{quote(config["tag"], safe="")}'
    for artifact in sorted(linked):
        template = template.replace(f'href="/downloads/{artifact}"', f'href="{base}/{quote(artifact)}"')
    template = template.replace('"/assets/', '"./assets/')
    args.out.mkdir(parents=True, exist_ok=True)
    shutil.copytree(ROOT / 'assets', args.out / 'assets', dirs_exist_ok=True)
    (args.out / 'index.html').write_text(template, encoding='utf-8')
    (args.out / '.nojekyll').touch()
    print(f'Pages site written to {args.out}; downloads point to {base}')


if __name__ == '__main__':
    main()
